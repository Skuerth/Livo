//
//  StatusBarShowingViewController.swift
//  ParkingBuddy
//
//  Created by Sergey Krotkih on 3/11/2015.
//  Copyright © 2015 Coded.dk. All rights reserved.
//

import UIKit

class StatusBarShowingViewController: UIViewController {

    override var prefersStatusBarHidden : Bool {
        return false
    }

}
